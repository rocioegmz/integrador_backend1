package com.example.proyecto_integrador.repository;

import com.example.proyecto_integrador.domain.Odontologo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OdontologoRepository extends JpaRepository<Odontologo, Long> {
}

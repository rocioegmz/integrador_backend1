package com.example.proyecto_integrador.domain;

public enum UsuarioRol {
    ROLE_USER, ROLE_ADMIN;
}
